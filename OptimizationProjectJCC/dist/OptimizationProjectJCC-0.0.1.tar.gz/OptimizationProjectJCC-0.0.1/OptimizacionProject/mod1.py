def mi_metodo():
    return "¡Hola desde mi_metodo en modulo1!"
